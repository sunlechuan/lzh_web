//下拉固定边框
var jWindow = $(window);
        jWindow.scroll(function(){
            var scrollHeight = jWindow.scrollTop();
            var screenHeight = jWindow.height();
            var sideHeight = $("#slider_content").height();
            if(scrollHeight + screenHeight> sideHeight){
            	console.log(scrollHeight + "当前到最顶高度");
            	console.log(screenHeight + "可视区域屏幕高度");
            	console.log(scrollHeight + screenHeight);
            	console.log(sideHeight + "边框高度");
                $("#slider_content").css({
                    'position':'fixed',
                    'top':-(sideHeight-screenHeight+150),
                    'right':116
                })
            }else{
                $("#slider_content").css({
                    'position':'static',
                })
            }
        })
        window.onload = function(){
            jWindow.trigger('scroll');
        }
        jWindow.resize(function () {
            jWindow.trigger('scroll');
})
        

 var toggleButton = document.querySelector('.navbar-toggle');
	     var collapsedElm = document.querySelector('.navbar-collapse');
	     toggleButton.addEventListener('click', function() {
	       collapsedElm.classList.toggle('collapse');
	     });
	   var navList = document.getElementById('navList');
	   var oList=navList.getElementsByTagName("a");
	   for(var i=0;i<oList.length;i++){
	       oList[i].onclick=function(){
	           for(var j=0;j<oList.length;j++){
	             oList[j].className="";
	           }
	           this.className+="active";
	       }
	   }