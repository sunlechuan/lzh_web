package cn.ssm.dao;

import java.util.List;
import cn.ssm.domain.Product;

public interface ProductMapper {

	public void saveProduct(Product product);
	
	public void editProduct(Product product);
	
	public Product findByPid(Product product);
	
	public List<Product> listProduct();
	
	public List<Product> search(Product product);
}
