package cn.ssm.dao;

import cn.ssm.domain.User;

public interface UserMapper {

	public void saveUser(User user);
	
	public User login(User user);
	
	public User findByUsername(User user);
}
