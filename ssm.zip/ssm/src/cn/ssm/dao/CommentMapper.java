package cn.ssm.dao;

import java.util.List;

import cn.ssm.domain.Comment;

public interface CommentMapper {
	
	public void saveComment(Comment comment);
	
	public List<Comment> listComment();
	
}
