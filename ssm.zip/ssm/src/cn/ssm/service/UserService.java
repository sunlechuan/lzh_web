package cn.ssm.service;

import  cn.ssm.domain.User;;

public interface UserService {

	public void saveUser(User user);
	
	public User login(User user);
	
	public User findByUsername(User user);
}
