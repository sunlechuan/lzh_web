package cn.ssm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import cn.ssm.dao.ProductMapper;
import cn.ssm.domain.Product;
import cn.ssm.service.ProductService;

@Service("/productService")
@Transactional
public class ProductServiceImpl implements ProductService {

	@Resource
	private ProductMapper productmapper;

	@Override
	public void saveProduct(Product product) {
		// TODO Auto-generated method stub
		productmapper.saveProduct(product);
	}

	@Override
	public void editProduct(Product product) {
		// TODO Auto-generated method stub
		productmapper.editProduct(product);
	}

	@Override
	public Product findByPid(Product product) {
		// TODO Auto-generated method stub
		return productmapper.findByPid(product);
	}

	@Override
	public List<Product> listProduct() {
		// TODO Auto-generated method stub
		return productmapper.listProduct();
	}

	@Override
	public List<Product> search(Product product) {
		// TODO Auto-generated method stub
		return productmapper.search(product);
	}

}
