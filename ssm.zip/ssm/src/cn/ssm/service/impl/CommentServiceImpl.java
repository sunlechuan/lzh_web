package cn.ssm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.ssm.dao.CommentMapper;
import cn.ssm.domain.Comment;
import cn.ssm.service.CommentService;

@Service("/commentService")
@Transactional
public class CommentServiceImpl implements CommentService {
	@Resource
	private CommentMapper commentMapper;

	@Override
	public void saveComment(Comment comment) {
		// TODO Auto-generated method stub
		commentMapper.saveComment(comment);
	}

	@Override
	public List<Comment> listComment() {
		// TODO Auto-generated method stub
		return commentMapper.listComment();
	}

}
