package cn.ssm.service;

import java.util.List;

import cn.ssm.domain.Comment;

public interface CommentService {
	
	public void saveComment(Comment comment);
	
	public List<Comment> listComment();
}
