package cn.ssm.service;

import java.util.List;
import cn.ssm.domain.Product;

public interface ProductService {

	public void saveProduct(Product product);
	
	public void editProduct(Product product);
	
	public Product findByPid(Product product);
	
	public List<Product> listProduct();
	
	public List<Product> search(Product product);
}
