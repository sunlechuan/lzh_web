package cn.ssm.controller;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.ssm.domain.User;
import cn.ssm.domain.Comment;
import cn.ssm.service.CommentService;
import cn.ssm.service.UserService;
import net.sf.json.JSONObject;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Resource
	private UserService userservice;
	
	@RequestMapping("/gologin")
	public String gologin() {
		
		return "user/login";
	}

	@RequestMapping("/login")
	public String login(User user,HttpServletResponse response,HttpSession session) {
		System.out.println(user);
		user = userservice.login(user);
		int user_id = 0;
		if(user == null) {
			return "redirect:/user/goAdd.action";
		}else {
			  user_id = user.getUser_id();
			  session.setAttribute("user_id", user_id);
			  session.setAttribute("user", user);
			  System.out.println(session.getAttribute("user"));
			return "redirect:/product/listProduct.action";
		}
		
	}
	
	@RequestMapping("/goAdd")
	public String goAdd() {
		
		return "user/register";
	}
	
	@RequestMapping("/add")
	public String add(User user) {
		System.out.println(user);
		if(null == userservice.findByUsername(user)) {
			userservice.saveUser(user);
			return "user/login";
		}else {
			System.out.println("�û��Ѵ���");
		}
		return "user/login";
	}
	@RequestMapping("/findByUser")
	@ResponseBody
	public User findByUser(User user) {
		System.out.println(user.getUsername());		
		user = userservice.findByUsername(user);
		return user;		
	}
}