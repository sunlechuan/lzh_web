package cn.ssm.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import cn.ssm.domain.Product;
import cn.ssm.domain.User;
import cn.ssm.service.ProductService;

@Controller
@RequestMapping("/product")
public class ProductController {

	@Resource
	private ProductService productservice;
    // �ϴ��ļ��洢Ŀ¼
    private static final String UPLOAD_DIRECTORY = "upload";
 
    // �ϴ�����
    private static final int MEMORY_THRESHOLD   = 1024 * 1024 * 3;  // 3MB
    private static final int MAX_FILE_SIZE      = 1024 * 1024 * 40; // 40MB
    private static final int MAX_REQUEST_SIZE   = 1024 * 1024 * 50; // 50MB
	
	//�г���Ʒ�б�
	@RequestMapping("/listProduct")
	@ResponseBody
	public ModelAndView listProduct(String keywords) {
		System.out.println(keywords);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("product/index");
		List<Product> varList = productservice.listProduct();
		mv.addObject("varList", varList);
		return mv;
	}
	
	
	
	//ȥ�޸�
		@RequestMapping("/gogoedit")
		@ResponseBody
		public ModelAndView gogoedit(Product product,HttpSession session) {
			ModelAndView mv = new ModelAndView();
			mv.setViewName("product/editProduct");
			int pid = product.getPid();
			mv.addObject("product", product);
			session.setAttribute("product", product);
			System.out.println(pid);
			return mv;
		}
		//ȥ�޸�
				@RequestMapping("/goedit")
				@ResponseBody
				public ModelAndView goedit(HttpSession session, Product product) {
					ModelAndView mv = new ModelAndView();
					System.out.println(session.getAttribute("user") == null);
					if(session.getAttribute("user") == null) {
						System.out.println("--");
						mv.setViewName("redirect:/user/gologin.action");
						return mv;
			        }else {
			        	System.out.println(session.getAttribute("user"));
			        	mv.setViewName("product/editProduct");
			        	product = (Product)session.getAttribute("product");
						product = productservice.findByPid(product);
						System.out.println(product + "goedit");			
						mv.addObject("product", product);
						return mv;
			        }
				}
		//�޸�
		@RequestMapping("/edit")
		public ModelAndView edit(Product product) {
			Date date = new Date();
			System.out.println(product);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String pdate = sdf.format(date);
			product.setPdate(pdate);
			System.out.println(product + "�ύedit");
			productservice.editProduct(product);
			return new ModelAndView("redirect:/product/listProduct.action");
		}
		
		
		
	//ȥ����ҳ��
	@RequestMapping("/gosave")
	public String gosave(HttpServletResponse response,HttpServletRequest request,HttpSession session) throws UnsupportedEncodingException {
		 boolean flag = false;
		 request.setCharacterEncoding("utf-8");
	     response.setContentType("text/html;charset=utf-8");
		
	     
	        if(session.getAttribute("user") == null) {
	        	return "redirect:/user/gologin.action";
	        }else {
	        	
	        	return "product/saveProduct";
	        }
	}
	//����
	@RequestMapping("/save")
	public ModelAndView save(Product product,HttpServletRequest request,HttpServletResponse response,HttpSession session) {
		User user = (User) session.getAttribute("user");
		System.out.println(user);
		product.setPshop(user.getName());
		System.out.println(user.getName());
		
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String pdate = sdf.format(date);
		product.setPdate(pdate);
		System.out.println(product);
		
		// ����Ƿ�Ϊ��ý���ϴ�
        if (!ServletFileUpload.isMultipartContent(request)) {
            // ���������ֹͣ
            PrintWriter writer = null;
			try {
				writer = response.getWriter();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            writer.println("Error: ����������� enctype=multipart/form-data");
            writer.flush();
        }
 
        // �����ϴ�����
        DiskFileItemFactory factory = new DiskFileItemFactory();
        // �����ڴ��ٽ�ֵ - �����󽫲�����ʱ�ļ����洢����ʱĿ¼��
        factory.setSizeThreshold(MEMORY_THRESHOLD);
        // ������ʱ�洢Ŀ¼
        factory.setRepository(new File(System.getProperty("java.io.tmpdir")));
 
        ServletFileUpload upload = new ServletFileUpload(factory);
         
        // ��������ļ��ϴ�ֵ
        upload.setFileSizeMax(MAX_FILE_SIZE);
         
        // �����������ֵ (�����ļ��ͱ�������)
        upload.setSizeMax(MAX_REQUEST_SIZE);
        
        // ���Ĵ���
        upload.setHeaderEncoding("UTF-8"); 

        // ������ʱ·�����洢�ϴ����ļ�
        // ���·����Ե�ǰӦ�õ�Ŀ¼
        String uploadPath = request.getServletContext().getRealPath("/") + File.separator + UPLOAD_DIRECTORY;
       System.out.println("uploadPath ---" + uploadPath);
         
        // ���Ŀ¼�������򴴽�
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdir();
        }
 
        try {
            // ���������������ȡ�ļ�����
            @SuppressWarnings("unchecked")
            List<FileItem> formItems = upload.parseRequest(request);
 
            if (formItems != null && formItems.size() > 0) {
                // ������������
                for (FileItem item : formItems) {
                    // �������ڱ����е��ֶ�
                    if (!item.isFormField()) {
                        String fileName = new File(item.getName()).getName();
                        String filePath = uploadPath + File.separator + fileName;
                        File storeFile = new File(filePath);
                        // �ڿ���̨����ļ����ϴ�·��
                        System.out.println(filePath);
                        
                        // �����ļ���Ӳ��
                        item.write(storeFile);
                        
                        String filePath1 = "http://localhost:8080/JD/upload/"+ fileName;
                        product.setPimg(filePath1);
                    }else {
                    	String name = item.getFieldName();                   	
                    	if(name.equals("pname")) {
                    		String value = new String(item.getString().getBytes("ISO-8859-1"), "utf-8");
                    		product.setPname(value);
                    	}else if(name.equals("pdesc")) {
                    		String value = new String(item.getString().getBytes("ISO-8859-1"), "utf-8");
                    		product.setPdesc(value);
                    	}else if(name.equals("price")) {
                    		String value = new String(item.getString().getBytes("ISO-8859-1"), "utf-8");
                    		double price = Double.valueOf(value.toString());
                    		product.setPrice(price);
                    	}
                    }
                }
            }
        } catch (Exception ex) {
            request.setAttribute("message",
                    "������Ϣ: " + ex.getMessage());
        }		
		
		
		System.out.println(product);
		productservice.saveProduct(product);
//		ModelAndView mv = new ModelAndView();
//		mv.setViewName("product/listProduct");
//		List<Product> varList = productservice.listProduct();
//		mv.addObject("varList", varList);
		return new ModelAndView("redirect:/product/listProduct.action");
	}
	
	
	
	//ģ����ѯ
	@RequestMapping("/search")
	@ResponseBody
	public List<Product> search(Product product) {
		String pname = product.getPname();
		System.out.println(pname);
		System.out.println(pname.equals(""));
		if(!pname.equals("")) {
			System.out.println("---");
			return productservice.search(product);
		}else {
			System.out.println("++++");
			return null;
		}
	}
}
