package cn.ssm.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonGenerator;
import com.sun.net.httpserver.HttpContext;

import cn.ssm.domain.Comment;
import cn.ssm.service.CommentService;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@CrossOrigin
@Controller
@RequestMapping("/comment")
public class CommentController {
	
	@Resource
	private CommentService commentService;
	
	
	@RequestMapping("/gosaveComment")
	public String gosaveComment(Comment comment) {
		
		return "comment";
	}
	
	@RequestMapping("/saveComment")
	@ResponseBody
	public String saveComment(Comment comment,String callback) {
		System.out.println("------------");
		System.out.println(comment);
		String result = "[{'msg':'true'}]";
		result = callback +"("+result+")";
		commentService.saveComment(comment);
		return result;
	}
	
	@RequestMapping(value = "/listComment", produces = "application/json; charset=utf-8")
	@ResponseBody
	public String listComment(String callback,HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		List<Comment> list = commentService.listComment();	
		System.out.println(callback+"("+list+")");
		String result = "[{'msg':'true','msg':1,'email':'343624128@qq.com'},{'msg':'true'}]";
		result=callback+"("+list+")";		
		System.out.println(result);
		return result;
	}

	@RequestMapping("/list")
	@ResponseBody
	public List<Comment> list(String callback) throws IOException {
		
		return commentService.listComment();
	}
}
