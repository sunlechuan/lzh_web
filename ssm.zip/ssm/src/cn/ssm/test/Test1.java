package cn.ssm.test;

import java.util.Scanner;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.ssm.dao.UserMapper;
import cn.ssm.domain.User;
import cn.ssm.service.UserService;

public class Test1 {

	@Test
	public void test(){
		int a;		
		int x = (int)(Math.random()*10);
		int y = (int)(Math.random()*10);
		while(y == x) {
			y = (int)(Math.random()*10);
		}
		int z = (int)(Math.random()*10);
		while(z == x || z == y) {
			z = (int)(Math.random()*10);
		}
		int w = (int)(Math.random()*10);
		while(w == x || w ==y || w == z) {
			w = (int)(Math.random()*10);
		}	
		a = x*1000+y*100+z*10+w;
		System.out.println(a);
		for(int i=0;i<10;i++) {
			Scanner sc = new Scanner(System.in);
			int sca = sc.nextInt();
			if(sca<a) {
				System.out.println("С");
			}else if(sca>a) {
				System.out.println("��");
			}else {
				System.out.println("����");
			}
		}
		 
	}
}
