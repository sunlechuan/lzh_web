package cn.ssm.domain;

public class Comment {
	public int id;
	private String nicheng;
	private String email;
	private String comment;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNicheng() {
		return nicheng;
	}
	public void setNicheng(String nicheng) {
		this.nicheng = nicheng;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public Comment() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "{'id':" + "'" + id + "'" + ", 'nicheng':" + "'" + nicheng + "'" + ", 'email':" + "'" + email + "'" + ", 'comment':" + "'" + comment + "'" + "}";
	}
	public Comment(int id, String nicheng, String email, String comment) {
		super();
		this.id = id;
		this.nicheng = nicheng;
		this.email = email;
		this.comment = comment;
	}

	

}
