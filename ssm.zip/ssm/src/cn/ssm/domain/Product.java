package cn.ssm.domain;

public class Product {

	private int pid;
	private String pname;
	private double price;
	private String pdesc;
	private String pshop;
	private String pimg;
	private String pdate;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getPdesc() {
		return pdesc;
	}
	public void setPdesc(String pdesc) {
		this.pdesc = pdesc;
	}
	public String getPshop() {
		return pshop;
	}
	public void setPshop(String pshop) {
		this.pshop = pshop;
	}
	public String getPimg() {
		return pimg;
	}
	public void setPimg(String pimg) {
		this.pimg = pimg;
	}
	public String getPdate() {
		return pdate;
	}
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	@Override
	public String toString() {
		return "{'pid':" + "'" + pid + "'" + ", 'pname':" + "'" + pname + "'" + ", 'price':" + "'" + price + "'" + ", 'pdesc':" + "'" + pdesc + "'"+ ", 'pshop':" + "'" + pshop + "'" + ", 'pdesc':" + "'" + pdesc + "'"+ ", 'pimg':" + "'" + pimg + "'"+ ", 'pdate':" + "'" + pdate + "'" + "}";
	}
	public Product(int pid, String pname, double price, String pdesc, String pshop, String pimg, String pdate) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.price = price;
		this.pdesc = pdesc;
		this.pshop = pshop;
		this.pimg = pimg;
		this.pdate = pdate;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
